/*
 *  stdint.h - integer types
 *
 *	$Id: stdbool.h,v 1.1 2012/04/20 15:46:39 stefano Exp $
 */

#ifndef __STDBOOL_H__
#define __STDBOOL_H__

#include <sys/compiler.h>

typedef unsigned int bool;

#endif

